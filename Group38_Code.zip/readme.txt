1. Install the package
    In the root directory, run "npm install" 
    In ./server, run "npm install"
2. Build the website
    In the root directory, run "npm run build"
3. Start the server
    In the root directory, run "node server"

The server will host on port 4000
You can access the website by http://localhost:4000/ or http://"your ip":4000/